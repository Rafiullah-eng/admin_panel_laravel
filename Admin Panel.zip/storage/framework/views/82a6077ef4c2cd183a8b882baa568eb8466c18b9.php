<?php $__env->startSection('title','Add Project'); ?>
<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('projects.index')); ?>">Project</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page">Add Project</li>
	              	</ol>
	            </nav>
		    </div>
		<?php if(session('success')): ?>
			<p class="alert alert-success">Project added successfully.</p>
		<?php endif; ?>
		</div>
	</div>
	<div class="row">
	<div class="col-lg-12 equel-grid">
		<div class="grid">
			<p class="grid-header">Project Details</p>
			<div class="grid-body">
				<div class="item-wrapper">
					<form action="<?php echo e(url('/admin/projects')); ?>" method="POST" onsubmit="return loadingBtn(this)" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="">Category</label>
									<small class="field-required"> *</small>
									<select class="form-control" name="project_category_id" required>
										<option value="">--Select--</option>
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($category->id); ?>">
												<?php echo e($category->title); ?>

											</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="form-group">
									<label for="">Link</label>
									<small class="field-required"> *</small>
									<input type="text" class="form-control" name="link" placeholder="Website Link" required>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="">Title</label>
									<small class="field-required"> *</small>
									<input type="text" class="form-control" name="title" placeholder="Project Title" required>
								</div>
								<div class="form-group">
									<label for="">Select Banner</label>
									<small class="field-required"> *</small>
									<input type="file" class="form-control" name="banner" required>
								</div>
							</div>
						</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label for="">Description</label>
										<small class="field-required"> *</small>
										<textarea rows="3" class="form-control" name="description" placeholder="Description here..." required></textarea>
									</div>
								</div>
							</div>
						<div class="row">
							<div class="col-md-12" id="loading-btn">
								<button type="submit" class="btn btn-sm btn-primary">Add Project</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/projects/create.blade.php ENDPATH**/ ?>