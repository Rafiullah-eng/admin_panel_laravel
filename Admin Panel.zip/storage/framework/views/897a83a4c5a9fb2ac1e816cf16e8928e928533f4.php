<?php $__env->startSection('title','Office Details'); ?>
<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('offices.index')); ?>">Offices</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page"><?php echo e($office->name); ?></li>
	              	</ol>
	            </nav>
		    </div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="grid">
				<p class="grid-header">
					<?php echo e($office->name); ?> - Details
					
					<a href="<?php echo e(route('offices.edit',$office->office_slug)); ?>" class="btn btn-sm btn-neutral" style="float: right;">Update</a>
				</p>
				<div class="item-wrapper">
					<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<th>Office</th>
									<td><?php echo e($office->name); ?></td>
								</tr>
								<tr>
									<th>E-Mail</th>
									<td><?php echo e($office->email); ?></td>
								</tr>
								<tr>
									<th>Phone</th>
									<td><?php echo e($office->phone); ?></td>
								</tr>
								<tr>
									<th>Address</th>
									<td><?php echo e($office->address); ?></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/offices/show.blade.php ENDPATH**/ ?>