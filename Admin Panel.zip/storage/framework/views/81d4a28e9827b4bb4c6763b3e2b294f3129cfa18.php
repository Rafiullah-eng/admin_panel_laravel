<?php $__env->startSection('title','Offices'); ?>
<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page">Offices</li>
	              	</ol>
	            </nav>
		    </div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="grid">
				<p class="grid-header">
					Offices List
					<a href="<?php echo e(route('offices.create')); ?>" class="btn btn-sm btn-primary has-icon" style="float: right;">
	                	<i class="mdi mdi-plus"></i>
	               		Office
	               	</a>
				</p>
				<div class="item-wrapper">
					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th>Office</th>
									<th>Email</th>
									<th>Phone</th>
									<th>Update</th>
									<th>Details</th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>
										<td><?php echo e($office->name); ?></td>
										<td><?php echo e($office->email); ?></td>
										<td><?php echo e($office->phone); ?></td>
										<td>
											<a href="<?php echo e(route('offices.edit',$office->office_slug)); ?>" class="btn btn-sm btn-neutral">Edit</a>
						    			</td>
										<td>
											<a href="<?php echo e(route('offices.show',$office->office_slug)); ?>" class="btn btn-sm btn-neutral">View</a>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<tr>
										<td colspan="5">
											No record found.
										</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/offices/index.blade.php ENDPATH**/ ?>