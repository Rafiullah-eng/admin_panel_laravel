<?php $__env->startSection('title','Clients'); ?>
<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page">Clients</li>
	              	</ol>
	            </nav>
		    </div>
		<?php if(session('success')): ?>
			<p class="alert alert-success">Client logo deleted successfully.</p>
		<?php endif; ?>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="grid">
				<p class="grid-header">
					Clients List
					<a href="<?php echo e(route('clients.create')); ?>" class="btn btn-sm btn-primary has-icon" style="float: right;">
	                	<i class="mdi mdi-plus"></i>
	               		Client
	               	</a>
				</p>
				<div class="item-wrapper">
					<div class="row" style="padding: 10px;">
						<?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="col-md-5" style="margin: 10px; padding: 5px; border: 1px solid #f2f2f2;">
							<form action="<?php echo e(url('/admin/clients',$client->id)); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>
						        <button type="submit" class="btn btn-sm btn-danger" style="float: right;">x</button>
						    </form>
					        <img class="img-responsive" src="<?php echo e(asset('uploads/clients/'.$client->logo)); ?>">
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<div class="col-md-12">
								<p>No record found.</p>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/clients/index.blade.php ENDPATH**/ ?>