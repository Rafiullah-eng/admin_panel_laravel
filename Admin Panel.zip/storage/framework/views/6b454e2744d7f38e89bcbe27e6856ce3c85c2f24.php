<?php $__env->startSection('title','Settings'); ?>
<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page">Settings</li>
	              	</ol>
	            </nav>
		    </div>
		<?php if(session('success')): ?>
			<p class="alert alert-success">Successful.</p>
		<?php endif; ?>
	</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="grid">
				<p class="grid-header">
					Settings
					<?php if($setting): ?>
						<a href="<?php echo e(route('settings.edit',$setting->setting_slug)); ?>" class="btn btn-sm btn-primary" style="float: right;">
							<i class="mdi mdi-table-edit"></i> Update Settings
						</a>
					<?php else: ?>
						<a href="<?php echo e(route('settings.create')); ?>" class="btn btn-sm btn-primary has-icon" style="float: right;">
	                	<i class="mdi mdi-plus"></i>
	               		Setting
	               		</a>
	               	<?php endif; ?>
				</p>
				<div class="item-wrapper">
					<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<td>Fav Icon</td>
									<td>
										<img src="<?php echo e(asset('uploads/settings/'.$setting->fav_icon)); ?>" class="img-responsive" style="width: 50px; height: 50px;">
									</td>
								</tr>
								<tr>
									<td>Logo</td>
									<td>
										<img src="<?php echo e(asset('uploads/settings/'.$setting->site_logo)); ?>" class="img-responsive" style="width: 250px; height: 250px; box-shadow: 0 0 10px -5px rgba(0, 0, 0, 0.15);">
									</td>
								</tr>
								<tr>
									<td>Site Name</td>
									<td><?php echo e($setting->site_name); ?></td>
								</tr>
								<tr>
									<td>Opening Day</td>
									<td><?php echo e($setting->opening_day); ?></td>
								</tr>
								<tr>
									<td>Closing Day</td>
									<td><?php echo e($setting->closing_day); ?></td>
								</tr>
								<tr>
									<td>Opening Time</td>
									<td><?php echo e(\Carbon\Carbon::make($setting->opening_time)->format('g:i A')); ?></td>
								</tr>
								<tr>
									<td>Closing Time</td>
									<td><?php echo e(\Carbon\Carbon::make($setting->closing_time)->format('g:i A')); ?></td>
								</tr>
								<tr>
									<td>Phone Number</td>
									<td><?php echo e($setting->phone_number); ?></td>
								</tr>
								<tr>
									<td>E-Mail address</td>
									<td><?php echo e($setting->email_address); ?></td>
								</tr>
								<tr>
									<td>Facebook Link</td>
									<td><?php echo e($setting->facebook_link); ?></td>
								</tr>
								<tr>
									<td>Instagram Link</td>
									<td><?php echo e($setting->instagram_link); ?></td>
								</tr>
								<tr>
									<td>Address</td>
									<td><?php echo e($setting->location_address); ?></td>
								</tr>
								<tr>
									<td>Short Info</td>
									<td><?php echo e($setting->about_info_short); ?></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>