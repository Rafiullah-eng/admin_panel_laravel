<?php $__env->startSection('title','Project Categories'); ?>
<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page">Project Categories</li>
	              	</ol>
	            </nav>
		    </div>
		<?php if(session('success')): ?>
			<p class="alert alert-success">Project Category updated successfully.</p>
		<?php endif; ?>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="grid">
				<p class="grid-header">
					Categories List
					<a href="<?php echo e(route('project-categories.create')); ?>" class="btn btn-sm btn-primary has-icon" style="float: right;">
	                	<i class="mdi mdi-plus"></i>
	               		Category
	               	</a>
				</p>
				<div class="item-wrapper">
					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th>S.No</th>
									<th>Category</th>
									<th>Details</th>
								</tr>
							</thead>
							<tbody>
								<?php $sno = 1; ?>
								<?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>
										<td><?php echo e($sno++); ?></td>
										<td>
											<?php echo e($category->title); ?>

										</td>
										<td>
											<a href="<?php echo e(url('/admin/project-categories',$category->category_slug)); ?>" class="btn btn-sm btn-neutral">View</a>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<tr>
										<td colspan="3">
											No record found.
										</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/project-categories/index.blade.php ENDPATH**/ ?>