<?php $__env->startSection('title','Update Category'); ?>
<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('project-categories.index')); ?>">Project Categories</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page"><?php echo e($category->title); ?></li>
	              	</ol>
	            </nav>
		    </div>
		<?php if(session('success')): ?>
			<p class="alert alert-success">Project Category updated successfully.</p>
		<?php endif; ?>
		</div>
	</div>
	<div class="row">
	<div class="col-lg-12 equel-grid">
		<div class="grid">
			<p class="grid-header">Category Details</p>
			<div class="grid-body">
				<div class="item-wrapper">
					<form action="<?php echo e(url('/admin/project-categories',$category->id)); ?>" method="POST" enctype="multipart/form-data" onsubmit="return loadingBtn(this)" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<?php echo method_field('PUT'); ?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="">Title</label>
									<small class="field-required"> *</small>
									<input type="text" class="form-control" name="title" value="<?php echo e($category->title); ?>" required>
								</div>
								<div class="form-group">
									<label for="">Background Image</label>
									<small class="field-required"> * Can be null.</small>
									<input type="file" class="form-control" name="background">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="">Logo</label>
									<small class="field-required"> * Can be null.</small>
									<input type="file" class="form-control" name="icon">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12" id="loading-btn">
								<button type="submit" class="btn btn-sm btn-primary">Update Category</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/project-categories/edit.blade.php ENDPATH**/ ?>