<?php $__env->startSection('title','Add Client'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-12">
		<div class="grid">
			<nav aria-label="breadcrumb">
				<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
					<li class="breadcrumb-item">
						<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
					</li>
					<li class="breadcrumb-item">
						<a href="<?php echo e(route('clients.index')); ?>">Clients</a>
					</li>
					<li class="breadcrumb-item active" aria-current="page">Add Client</li>
				</ol>
			</nav>
		</div>
		<?php if(session('success')): ?>
			<p class="alert alert-success">Client logo added successfully.</p>
		<?php endif; ?>
	</div>
</div>
<div class="row">
	<div class="col-lg-12 equel-grid">
		<div class="grid">
			<p class="grid-header">Client Details</p>
			<div class="grid-body">
				<div class="item-wrapper">
					<form action="<?php echo e(url('/admin/clients')); ?>" method="POST" enctype="multipart/form-data" onsubmit="return loadingBtn(this)">
						<?php echo csrf_field(); ?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="">Select Logo</label>
									<small class="field-required"> *</small>
									<input type="file" name="logo" class="form-control" required>
								</div>
							</div>
							<div class="col-md-6"></div>
						</div>
						<div class="row">
							<div class="col-md-12" id="loading-btn">
								<button type="submit" class="btn btn-sm btn-primary">Add Client</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/clients/create.blade.php ENDPATH**/ ?>