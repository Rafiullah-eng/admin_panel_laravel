<?php $__env->startSection('title','Add SMTP'); ?>
<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('smtp.index')); ?>">SMTP Settings</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page">ADD SMTP</li>
	              	</ol>
	            </nav>
		    </div>
		</div>
	</div>
	<div class="row">
	<div class="col-lg-12 equel-grid">
		<div class="grid">
			<p class="grid-header">SMTP Details</p>
			<div class="grid-body">
				<div class="item-wrapper">
					<form action="<?php echo e(url('/admin/smtp')); ?>" method="POST" onsubmit="return loadingBtn(this)">
						<?php echo csrf_field(); ?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="">Driver</label>
									<small class="field-required"> * e.g. smtp.</small>
									<input type="text" class="form-control" name="driver" placeholder="Driver" required>
								</div>
								<div class="form-group">
									<label for="">Port</label>
									<small class="field-required"> * e.g. 587.</small>
									<input type="text" class="form-control" name="port" placeholder="Port" required>
								</div>
								<div class="form-group">
									<label for="">G-Mail password</label>
									<small class="field-required"> * e.g. account password.</small>
									<input type="text" class="form-control" name="password" placeholder="Account Password" required>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="">Host</label>
									<small class="field-required"> * e.g. smtp.mailtrap.io</small>
									<input type="text" class="form-control" name="host" placeholder="Host" required>
								</div>
								<div class="form-group">
									<label for="">G-Mail address</label>
									<small class="field-required"> * e.g. text@gmail.com.</small>
									<input type="text" class="form-control" name="username" placeholder="Host" required>
								</div>
								<div class="form-group">
									<label for="">Encryption</label>
									<small class="field-required"> * e.g. tls,ssl.</small>
									<input type="text" class="form-control" name="encryption" placeholder="Encryption" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12" id="loading-btn">
								<button type="submit" class="btn btn-sm btn-primary">Add SMTP</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/smtp/create.blade.php ENDPATH**/ ?>