<?php $__env->startSection('title','Testimonial Details'); ?>
<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-12">
			<div class="grid">
	            <nav aria-label="breadcrumb">
	              	<ol class="breadcrumb has-arrow" style="margin-bottom: 0px;">
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
	                	</li>
	                	<li class="breadcrumb-item">
	                  		<a href="<?php echo e(route('testimonials.index')); ?>">Testimonials</a>
	                	</li>
	                	<li class="breadcrumb-item active" aria-current="page"><?php echo e($testimonial->name); ?></li>
	              	</ol>
	            </nav>
		    </div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="grid">
				<p class="grid-header">
					Testimonial - Details
					
					<a href="<?php echo e(route('testimonials.edit',$testimonial->id)); ?>" class="btn btn-sm btn-neutral" style="float: right;">Update</a>
				</p>
				<div class="item-wrapper">
					<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<th>Customer</th>
									<td><?php echo e($testimonial->name); ?></td>
								</tr>
								<tr>
									<th>Feedback</th>
									<td><?php echo e($testimonial->feedback); ?></td>
								</tr>
								<tr>
									<th>Photo</th>
									<td>
										<img src="<?php echo e(asset('uploads/testimonials/'.$testimonial->picture)); ?>" class="img-responsive" style="width: 150px; height: 150px;">
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\unifiedtnc\resources\views/admin/testimonials/show.blade.php ENDPATH**/ ?>